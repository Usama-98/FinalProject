/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pharmacy;

/**
 *
 * @author Usama
 */
public class Pharmacy {
    
    private String pharmaName;
    private int pharmaID;
    private String pharmaLocation;
    private MedicineCatalog drugCatalog;

    @Override
    public String toString() {
        //return "Pharmacy{" + "pharmaName=" + pharmaName + '}';
        return pharmaName;
    }

    public Pharmacy(){
        drugCatalog = new MedicineCatalog();
    }
    public MedicineCatalog getDrugCatalog() {
        return drugCatalog;
    }

    public void setMedicineCatalog(MedicineCatalog medicineCatalog) {
        this.drugCatalog = medicineCatalog;
    }
    
    public String getStoreName() {
        return pharmaName;
    }

    public void setStoreName(String storeName) {
        this.pharmaName = storeName;
    }

    public int getStoreID() {
        return pharmaID;
    }

    public void setStoreID(int storeID) {
        this.pharmaID = storeID;
    }

    public String getStoreLocation() {
        return pharmaLocation;
    }

    public void setStoreLocation(String storeLocation) {
        this.pharmaLocation = storeLocation;
    }
    
    
}
