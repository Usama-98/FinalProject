/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pharmacy;

import java.util.ArrayList;

/**
 *
 * @author Usama
 */
public class AddData {
    
    public void setInitialValues(PharmacyDirectory pharmacyDirectory)
            
    {
        PharmacyDirectory pharmaDirectory = pharmacyDirectory;
        
       Pharmacy pharma1 = new Pharmacy();
               
       Pharmacy pharma2 = new Pharmacy();
       
               
       pharma1.setStoreName("AAAA");
       pharma2.setStoreName("BinHashim");
        
       pharmaDirectory.addPharmacy(pharma1);
      pharmaDirectory.addPharmacy(pharma2);
        Medicine drug1 = new Medicine();
        
        
        
        drug1.setMedicineName("Brufin");
        drug1.setMedidicneQuantity(40);
        drug1.setManufacturedDate("24-08-2020");
        drug1.setExpirationDate("12-08-2022");
        drug1.setMedicinePrice(150);
        
        
        pharma1.getDrugCatalog().addDrugs(drug1);
        
        Medicine drug2 = new Medicine();
       
        drug2.setMedicineName("Panadol");
        drug2.setMedidicneQuantity(80);
        drug2.setMedicinePrice(100);
        drug2.setManufacturedDate("24-08-2020");
        drug2.setExpirationDate("12-08-2022");
     
        pharma1.getDrugCatalog().addDrugs(drug2);
        
        Medicine drug12 = new Medicine();
        
        drug12.setMedicineName("Fexet-D");
        drug12.setMedidicneQuantity(80);
        drug12.setManufacturedDate("24-08-2020");
        drug12.setExpirationDate("12-08-2022");
        drug12.setMedicinePrice(200);
        pharma2.getDrugCatalog().addDrugs(drug12);
        
    }
    public void setStoreInitialValues(StoreDirectory storeDirectory){
        StoreDirectory sd = storeDirectory;
        
        Store store1 = new Store();
        
        Store store2 = new Store();
        
        
        store1.setStoreName("Store 1");
        store1.setStoreLocation("Karachi");
        sd.addStore(store1);
        
        store2.setStoreName("Store 2");
        store2.setStoreLocation("Lahore");
        sd.addStore(store2);
        
       
    }
                
}
