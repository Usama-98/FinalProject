/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pharmacy;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Usama
 */
public class PharmacyDirectory extends Thread  {
    
    ArrayList<Pharmacy> pharmaList;

    public PharmacyDirectory(){
        this.pharmaList =  new ArrayList<Pharmacy>();
    }
    public ArrayList<Pharmacy> getStoreList() {
        return pharmaList;
    }

    public void setStoreList(ArrayList<Pharmacy> storeList) {
        this.pharmaList = storeList;
    }

    public Pharmacy addPharmacy(Pharmacy pharma) {

        //Pharmacy pharma = new Pharmacy();
        pharmaList.add(pharma);
        return pharma;
    }

    public void removeSupplier(Pharmacy pharmacy) {
     pharmaList.remove(pharmacy);
    }

    public synchronized Medicine searchDrug(int medicineId)
    {
        synchronized(this){
            try{
        for(Pharmacy p : pharmaList){
        for(Medicine drug : p.getDrugCatalog().getDrugList()){
            if(medicineId == drug.getMedicineId())
                return drug;
        }
        }
        }
            catch(Exception e){
                System.out.println("The Drug is Not Found");
                      JOptionPane.showMessageDialog(null, "The Drug is not found in the inventory", "error",JOptionPane.INFORMATION_MESSAGE);  
            }
         }
        return null;
    }
}
