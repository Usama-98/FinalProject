/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pharmacy;

import java.util.Date;

/**
 *
 * @author Usama
 */
public class Medicine {
    
    private int medicineId;
    private String medicineName;
    private String expirationDate;
    private String manufacturedDate;
    private String composition;
    private String medicineType;
    private String medicineDescription;
    private int medicineQuantity;
    private int medicinePrice;

    private static int count;
    
    public Medicine(){
        count++;
        medicineId = count;
    }

    public synchronized String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    public String getManufacturedDate() {
        return manufacturedDate;
    }

    public void setManufacturedDate(String manufacturedDate) {
        this.manufacturedDate = manufacturedDate;
    }
    
    public String getMedicineDescription() {
        return medicineDescription;
    }

    public void setMedicineDescription(String medicineDescription) {
        this.medicineDescription = medicineDescription;
    }

    public int getMedicineQuantity() {
        return medicineQuantity;
    }

    public void setMedidicneQuantity(int medicineQuantity) {
        this.medicineQuantity = medicineQuantity;
    }

    public int getMedicinePrice() {
        return medicinePrice;
    }

    public void setMedicinePrice(int medicinePrice) {
        this.medicinePrice = medicinePrice;
    }

    public int getMedicineId() {
        
        return medicineId;
        
    }

   
   
    public String getMedicineName() {
        return medicineName;
    }

    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName;
    }

    public String getComposition() {
        return composition;
    }

    public void setComposition(String composition) {
        this.composition = composition;
    }

    public String getMedicineType() {
        return medicineType;
    }

    public void setMedicineType(String medicineType) {
        this.medicineType = medicineType;
    }

      @Override
    public String toString() {
       // return "Drug{" + "drugID=" + drugID + '}';
        return medicineName;
    }
    
   
}
