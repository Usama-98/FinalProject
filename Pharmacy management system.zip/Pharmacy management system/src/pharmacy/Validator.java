/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pharmacy;

import javax.swing.JOptionPane;

/**
 *
 * @author Usama
 */
public class Validator extends Thread {
  
        
    public void run(){
        
    }
    
    public synchronized boolean isValidInteger(String str) throws InterruptedException
    {
        synchronized(this){
        int price, quantity;
        try {
                price = Integer.parseInt(str);
                quantity = Integer.parseInt(str);
                return true;
        
            }
        
            catch(NumberFormatException e){
                System.out.println("Error Occured");
                Thread.sleep(2000);
                JOptionPane.showMessageDialog(null, "ERROR! Invalid Input","warning",JOptionPane.ERROR_MESSAGE);
                Thread.sleep(4000);
                    JOptionPane.showMessageDialog(null, "Please enter a valid input Number","warning",JOptionPane.ERROR_MESSAGE);
                    Thread.sleep(5000);
                   return false;
            }
    }
    }
   
    
    public boolean isStringValid(String str) throws InterruptedException
    {
        if(str.trim().isEmpty()){
            try {
            throw new Exception("Valueables cannot take in an empty String or null value for the Names!");
        } catch (Exception e) {
            Thread.sleep(3000);
            JOptionPane.showMessageDialog(null, "Fields Should not be empty","warning",JOptionPane.ERROR_MESSAGE);
           Thread.sleep(2000);
            e.printStackTrace();
            Thread.sleep(7000);
            System.exit(2);
        }
            return false;
        }
        else{
            return true;
        }
       
        
    }
    
}
